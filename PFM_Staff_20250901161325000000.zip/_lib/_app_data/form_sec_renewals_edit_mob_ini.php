<?php
    $arr_data = [];
    $arr_data['sc'] = "v9";
    $arr_data['sc_version'] = "9.12.008";
    $arr_data['sc_build'] = "4";
    $arr_data['prod_version'] = "1.0.003";
    $arr_data['prod_build'] = "2";
    $arr_data['initial'] = "form_sec_renewals_edit_mob.php";
    $arr_data['group'] = "PFM_Staff";
    $arr_data['apl'] = "form_sec_renewals_edit_mob";
    $arr_data['description'] = "";
    $arr_data['status'] = "NAO";
    $arr_data['type'] = "form";
    $arr_data['friendly_url'] = "form_sec_renewals_edit";
    $arr_data['md5'] = "LigMd5";
    $arr_data['md5_apl'] = "75f2565de2bbf19c4eb5dbba7c3e9f09";
    $arr_data['tem_var_form'] = "N";
    $arr_data['external_var'] = "N";
