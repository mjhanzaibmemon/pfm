<?php
    $arr_data = [];
    $arr_data['sc'] = "v9";
    $arr_data['sc_version'] = "9.12.008";
    $arr_data['sc_build'] = "4";
    $arr_data['prod_version'] = "1.0.003";
    $arr_data['prod_build'] = "2";
    $arr_data['initial'] = "index.php";
    $arr_data['group'] = "PFM_Staff";
    $arr_data['apl'] = "form_sec_renewals_edit";
    $arr_data['description'] = "";
    $arr_data['status'] = "NAO";
    $arr_data['type'] = "form";
    $arr_data['friendly_url'] = "form_sec_renewals_edit";
    $arr_data['md5'] = "LigMd5";
    $arr_data['md5_apl'] = "dd404d1fdda038f6fd42561f34399cea";
    $arr_data['tem_var_form'] = "N";
    $arr_data['external_var'] = "N";
