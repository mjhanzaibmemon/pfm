<?php
    $arr_data = [];
    $arr_data['sc'] = "v9";
    $arr_data['sc_version'] = "9.12.008";
    $arr_data['sc_build'] = "4";
    $arr_data['prod_version'] = "1.0.003";
    $arr_data['prod_build'] = "2";
    $arr_data['initial'] = "index.php";
    $arr_data['group'] = "PFM_Staff";
    $arr_data['apl'] = "grid_vw_clients_main_member_renew";
    $arr_data['description'] = "";
    $arr_data['status'] = "NAO";
    $arr_data['type'] = "cons";
    $arr_data['friendly_url'] = "grid_vw_clients_main_member_renew";
    $arr_data['md5'] = "LigMd5";
    $arr_data['md5_apl'] = "d5ffa565b1677adfb49ffbf14adbabb3";
    $arr_data['tem_var_form'] = "N";
    $arr_data['external_var'] = "Y";
